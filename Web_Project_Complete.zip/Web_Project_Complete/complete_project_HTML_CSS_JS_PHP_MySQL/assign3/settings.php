<!-- This is for account settings.
Author: MD Kafil Uddin
Created: 21 Oct
Last updated: 28 Oct -->
<?php
	// account details.
	$host = "feenix-mariadb.swin.edu.au";
	$user = "s102409230";
	$pwd = "141298";
	$sql_db = "s102409230_db";
?>